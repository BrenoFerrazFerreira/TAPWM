var num1;
var num2;
var produto;
var divisao;
var soma;
var subtracao;
var resto;

num1 = parseFloat(prompt("Informe o primeiro numero: "));
num2 = parseFloat(prompt("Informe o segundo numero: "));

produto = num1 * num2;
divisao = num1 / num2;
subtracao = num1 - num2;
adicao = num1 + num2;
resto = num1 % num2;

alert("Resutados: \n" + "Soma: " + adicao + "\nSubtração: " + 
subtracao + "\nProduto: " + produto + "\nDivisão: " + divisao +
"\nResto: " + resto);