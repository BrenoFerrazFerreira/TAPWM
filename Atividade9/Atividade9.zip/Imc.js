var peso = 0, 
altura = 0, 
imc = 0,
classificacao;

altura = parseFloat(prompt("Infome sua altura:"));
peso = parseFloat(prompt("Infome seu peso:"));

imc = peso / (altura * altura);

imc = Math.round(imc,1);

if (imc < 18.5){
    alert("Seu cálculo do IMC resultou em: " + imc + "\nClassificação: Magreza\nObesidade tipo: 0");
} 
else if (imc >= 18.5 && imc <= 24.9 ){
    alert("Seu cálculo do IMC resultou em: " + imc + "\nClassificação: Normal\nObesidade tipo: 0");
}
else if (imc >= 25 && imc <= 29.9){
    alert("Seu cálculo do IMC resultou em: " + imc + "\nClassificação: Sobrepeso\nObesidade tipo: 1");
}
else if (imc >= 30 && imc <= 39.9) {
    alert("Seu cálculo do IMC resultou em: " + imc + "\nClassificação: Obesidade\nObesidade tipo: 2");
}
else if (imc >= 40 ){
    alert("Seu cálculo do IMC resultou em: " + imc + "\nClassificação: Obesidade Grave\nObesidade tipo: 3");
}