/*
Criar uma função validar noevento onsubmit do Form.
Nome não pode ter menos que 10caracteres.
Email deve ter os caracteres @ e .Comentário deve ter no mínimo20 caracteres.
Pesquisa (obrigatório). Se não:Retornar : “Que bom que vocêvoltou a visitar esta página!”, casocontrário: “Volte sempre à estápágina!”. Utilize mesmo atributoname nos radios.
Utilizar
document.nomeform.elements[] nafunção – pelo menos em algumcaso*/
function validarForm(form){
    if(form.txtNome.value.lenght < 10){
        alert("O campo de Nome precisa ter no minimo 10 caracteres")
        return false;
    }
}