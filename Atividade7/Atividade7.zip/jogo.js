var escolha;
var escolha_maquina;
var jogo = ["pedra", "papel", "tesoura"];
var continuar = "s";

while (continuar == "s") {
    escolha = prompt("Pedra, papel ou tesoura?".toLowerCase());
    escolha_maquina = jogo[Math.floor(Math.random() * 3)];

    alert("Sua esoclha: " + escolha + "\nEscolha da máquina: " + escolha_maquina);

    if (escolha == escolha_maquina) {
        alert("Houve um empate!");
    } else if (escolha == "pedra" && escolha_maquina == "papel") {
        alert("você perdeu!\nPapel embrulha pedra!");
    } else if (escolha == "papel" && escolha_maquina == "pedra") {
        alert("você ganhou!\nPapel embrulha pedra!");
    } else if (escolha == "tesoura" && escolha_maquina == "papel") {
        alert("você ganhou!\nTesoura corta papel!");
    } else if (escolha == "papel" && escolha_maquina == "tesoura") {
        alert("você perdeu!\nTesoura corta papel!");
    } else if (escolha == "pedra" && escolha_maquina == "tesoura") {
        alert("você ganhou!\nPedra quebra tesoura!");
    } else if (escolha == "tesoura" && escolha_maquina == "pedra") {
        alert("você perdeu!\nPedra quebra tesoura!");
    }
    continuar = prompt("Deseja continuar? (s/n): ".toLowerCase());
}

alert("Obrigado por jogar!");