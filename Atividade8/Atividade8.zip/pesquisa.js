var idade, sexo, opiniao, maiorIdade = 0, maisNova = 999, 
quantidade = 0, total = 0, idadeAnterior = 0, pessimo = 0, mulher = 0, 
homem = 0, media = 0, quantidadeO = 0, porcentagem = 0;


for (var i=0; i<45; i++){
    idade = parseInt(prompt("informe sua idade: "));
    sexo = prompt("informe seu sexo: ");
    opiniao = prompt("Qual a sua opiniao? \nótimo = 4\nbom=3\nregular=2\npéssimo=1");

    quantidade += 1;
    total += idade;
    maiorIdade = (idade > maiorIdade ? idade : maiorIdade);
    maisNova = (idade < maisNova ? idade : maisNova);
    pessimo = (opiniao == 1 ? pessimo + 1 : pessimo );
    mulher = (sexo == "mulher" ? mulher + 1 : mulher );
    homem = (sexo == "homem" ? homem + 1 : homem + 0);
    quantidadeO = (opiniao == 4 || opiniao == 3 ? quantidadeO + 1 : quantidadeO)
    idadeAnterior = idade;
}

porcentagem = (quantidadeO * 100) / 45;

media = total / quantidade;

alert("media: " + media + 
"\npessoa mais velha: " + 
maiorIdade + "\npessoa mais nova: " + 
maisNova +"\nquantidade de pessimos: " + pessimo + 
"\nporcentagem: " + porcentagem + "%" +
"\nquantidade mulheres: " + mulher + 
"\nquantidade homens: " + homem);